<?php
	//Informations de connexion à la base de données
	define('DB_TYPE', 'mysql');
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'bd');
    define('DB_USER', 'root');
    define('DB_PASS', '');
?>